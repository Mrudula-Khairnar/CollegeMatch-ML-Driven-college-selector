from django.apps import AppConfig


class CollegeMatchAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'college_match_app'
